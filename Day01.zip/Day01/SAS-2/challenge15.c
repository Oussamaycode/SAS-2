#include<stdio.h>
#include<math.h>
int main(){
char c;
printf("entrez un caractere:");
scanf("%c",&c);
switch(c){
case 'a':
printf("le caractere entree est un voyelle");
break;
case 'e':
printf("le caractere entree est un voyelle");
break;
case 'i':
printf("le caractere entree est un voyelle");
break;
case 'o':
printf("le caractere entree est un voyelle");
break;
case 'u':
printf("le caractere entree est un voyelle");
break;
case 'y':
printf("le caractere entree est un voyelle");
break;
default:
printf("le caractere entree n'est pas un voyelle");}

return 0;
}