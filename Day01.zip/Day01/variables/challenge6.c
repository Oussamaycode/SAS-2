#include <stdio.h>
#include<string.h>
int main() {
	float a,b,s1,s2,p,d;
	printf("entrez la valeur de a:");
	scanf("%f",&a);
	printf("entrez la valeur de b:");
	scanf("%f",&b);
	s1=a+b;
	p=a*b;
	s2=a-b;
	d=a/b;
	printf("a + b =%f\na - b=%f\na x b =%f\na / b =%f",s1,s2,p,d);
	return 0;
    
}
